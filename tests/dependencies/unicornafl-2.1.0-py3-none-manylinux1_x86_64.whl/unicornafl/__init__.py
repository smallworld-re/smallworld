from .unicornafl import uc_afl_fuzz, uc_afl_fuzz_custom, monkeypatch, UcAflError, UC_AFL_RET_OK, UC_AFL_RET_ERROR, UC_AFL_RET_CHILD, UC_AFL_RET_NO_AFL, UC_AFL_RET_CALLED_TWICE, UC_AFL_RET_FINISHED
# Compatibility
from unicorn import *